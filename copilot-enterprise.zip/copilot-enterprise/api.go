package main

import (
	"context"
	"copilot-enterprise/typs"
	"copilot-enterprise/vars"
	"encoding/json"
	"fmt"
	"github.com/gin-gonic/gin"
	"log"
	"math/rand"
	"net/http"
	"strings"
	"time"
)

func AuthMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		token := c.GetHeader("Authorization")
		var split []string
		if strings.Contains(token, "Bearer ") {
			if split = strings.SplitN(token, "Bearer ", 2); len(split) != 2 {
				c.AbortWithStatusJSON(403, vars.ErrEpuTokenAuthWithFormattingError)
				return
			}
		} else if strings.Contains(token, "token ") {
			if split = strings.SplitN(token, "token ", 2); len(split) != 2 {
				c.AbortWithStatusJSON(403, vars.ErrEpuTokenAuthWithFormattingError)
				return
			}
		}
		c.Set("deviceCode", split[1])
		c.Next()
	}
}

func UserHandler() gin.HandlerFunc {
	return func(c *gin.Context) {
		deviceCode := c.MustGet("deviceCode").(string)
		var deviceBind typs.DeviceBind
		err := sContext.Db.
			Where("device_code = ?", deviceCode).Preload("ActivateCode").First(&deviceBind).Error
		if err != nil {
			c.AbortWithStatusJSON(403, vars.ErrTokenAuthWithUnAvailable)
			return
		}
		if time.Now().After(deviceBind.ActivateCode.UsedDate.Add(deviceBind.ActivateCode.ValidUntil)) {
			c.AbortWithStatusJSON(403, vars.ErrTokenAuthWithExpired)
			return
		}
		c.JSON(200, gin.H{
			"login": deviceBind.ActivateCode.Name,
			"id":    deviceBind.ID,
			"name":  deviceBind.ActivateCode.Name,
		})
	}
}

func createAPIRoute(r *gin.Engine) {
	r.StaticFile("/favicon.ico", "etc/favicon.ico")
	r.GET("/user", AuthMiddleware(), UserHandler())
	r.GET("/api/v3/user", AuthMiddleware(), UserHandler())
	r.GET("/meta", func(c *gin.Context) {
		c.JSON(200, gin.H{})
	})
	r.GET("/api/v3/meta", func(c *gin.Context) {
		c.JSON(200, gin.H{})
	})
	r.POST("/login/device/code", func(c *gin.Context) {
		userCode := fmt.Sprintf("%04X-%04X", rand.Intn(0x10000), rand.Intn(0x10000))
		epuToken := GenerateToken("epu_", 36)
		_, err := sContext.BindPool.Set(context.Background(), userCode, epuToken, 10*time.Minute).Result()
		if err != nil {
			c.AbortWithStatusJSON(403, gin.H{"error": "Service internal errors"})
			return
		}
		c.JSON(200, gin.H{
			"user_code":        userCode,
			"verification_uri": sContext.Conf.VerificationUrl,
			"interval":         5,
			"device_code":      epuToken,
			"expires_in":       600,
		})
	})
	r.POST("/login/oauth/access_token", func(c *gin.Context) {
		loginRequest, err := handlePost(c)
		if err != nil {
			c.AbortWithStatusJSON(403, vars.AccessTokenResult)
			return
		}
		var result typs.DeviceBind
		err = sContext.Db.
			Where("device_code = ?", loginRequest.DeviceCode).Preload("ActivateCode").First(&result).Error
		if err != nil {
			c.AbortWithStatusJSON(403, vars.AccessTokenResult)
			return
		}
		c.JSON(200, gin.H{
			"access_token": result.DeviceCode,
			"scope":        "",
			"token_type":   "bearer",
		})
	})
	r.GET("/copilot_internal/v2/token", AuthMiddleware(), func(c *gin.Context) {
		deviceCode := c.MustGet("deviceCode").(string)
		var deviceBind typs.DeviceBind
		err := sContext.Db.Where("device_code = ?", deviceCode).Preload("ActivateCode").First(&deviceBind).Error
		if err != nil {
			c.AbortWithStatusJSON(403, vars.ErrTokenAuthWithNeedReActivate)
			return
		}
		if deviceBind.ActivateCode == nil {
			c.AbortWithStatusJSON(403, vars.ErrTokenWithNeedRecharge)
			return
		}
		if time.Now().After(deviceBind.ActivateCode.UsedDate.Add(deviceBind.ActivateCode.ValidUntil)) {
			c.AbortWithStatusJSON(403, vars.ErrTokenAuthWithExpired)
			return
		}
		if !sContext.Limiter.Allow(deviceCode, c.ClientIP()) {
			c.AbortWithStatusJSON(403, vars.ErrTokenWithTooManyRequests)
			return
		}
		go func() {
			err = sContext.Db.Create(&typs.History{
				DeviceCode: deviceBind.DeviceCode,
				IP:         c.ClientIP(),
			}).Error
			if err != nil {
				log.Println(err)
			}
			err = sContext.Db.Model(&typs.DeviceBind{}).Where("device_code = ?", deviceCode).
				Update("editor_version", c.GetHeader("Editor-Version")).
				Update("editor_plugin_version", c.GetHeader("Editor-Plugin-Version")).
				Update("user_agent", c.GetHeader("User-Agent")).Error
			if err != nil {
				log.Println(err)
			}
		}()
		var gitResp typs.GithubAuthResponse
		rotationCycleTime := time.Duration(sContext.Conf.ClientSet.RotationCycle) * time.Second
		key, err := sContext.UserPool.Get(context.Background(), deviceBind.ActivateCode.Code).Result()
		if err != nil {
			if key, tokenJson, err := sContext.GhuPool.GetKeyValueRandom(); err == nil {
				err = json.Unmarshal([]byte(tokenJson), &gitResp)
				if err != nil {
					panic(err)
				}
				HandleToken(&gitResp)
				_, err := sContext.UserPool.Set(context.Background(), deviceBind.ActivateCode.Code, key, rotationCycleTime).Result()
				if err != nil {
					panic(err)
				}
				c.JSON(200, gitResp)
				return
			}
		} else {
			jsonData, err := sContext.GhuPool.GetValue(key)
			if err != nil {
				if key, tokenJson, err := sContext.GhuPool.GetKeyValueRandom(); err == nil {
					err = json.Unmarshal([]byte(tokenJson), &gitResp)
					if err != nil {
						panic(err)
					}
					HandleToken(&gitResp)
					_, err := sContext.UserPool.Set(context.Background(), deviceBind.ActivateCode.Code, key, rotationCycleTime).Result()
					if err != nil {
						panic(err)
					}
					c.JSON(200, gitResp)
					return
				}
			}
			err = json.Unmarshal([]byte(jsonData), &gitResp)
			if err != nil {
				panic(err)
			}
			HandleToken(&gitResp)
			_, err = sContext.UserPool.Set(context.Background(), deviceBind.ActivateCode.Code, key, rotationCycleTime).Result()
			if err != nil {
				panic(err)
			}
			c.JSON(200, gitResp)
			return
		}
		c.AbortWithStatusJSON(403, vars.ErrTokenWithServiceAbnormal)
		return
	})
}

func HandleToken(gitResp *typs.GithubAuthResponse) {
	gitResp.ChatEnabled = sContext.Conf.Deploy.ChatEnabled
	gitResp.ChatJetbrainsEnabled = sContext.Conf.Deploy.ChatJetbrainsEnabled
	gitResp.PublicSuggestions = sContext.Conf.Deploy.PublicSuggestions
	gitResp.Telemetry = sContext.Conf.Deploy.Telemetry

	// 过期时间减去当前时间
	gitResp.RefreshIn = sContext.Conf.ClientSet.RefreshInterval
	now := time.Now().Unix()
	tim := gitResp.ExpiresAt - now
	if tim > gitResp.RefreshIn {
		tim = gitResp.RefreshIn
	}
	gitResp.ExpiresAt += now + tim + 1
}

func handlePost(c *gin.Context) (*typs.LoginRequest, error) {
	var loginReq *typs.LoginRequest

	// 获取Content-Type
	contentType := c.GetHeader("Content-Type")

	// 根据Content-Type选择相应的序列化方法
	switch contentType {
	case "application/json":
		// 对于JSON类型的请求体，使用ShouldBindJSON方法
		if err := c.ShouldBindJSON(&loginReq); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			return loginReq, err
		}
	case "application/x-www-form-urlencoded":
		// 对于Form类型的请求体，使用ShouldBind方法
		if err := c.ShouldBind(&loginReq); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			return loginReq, err
		}
	case "":
		if err := c.BindQuery(&loginReq); err != nil {
			c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
			return loginReq, err
		}
	}
	return loginReq, nil
}
