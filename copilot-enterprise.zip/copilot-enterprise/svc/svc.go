package svc

import (
	"copilot-enterprise/config"
	"copilot-enterprise/limiter"
	"copilot-enterprise/tokens"
	"copilot-enterprise/typs"
	"github.com/go-redis/redis/v8"
	"github.com/pquerna/otp"
	"github.com/pquerna/otp/totp"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"gorm.io/gorm/logger"
	"log"
	"os"
	"time"
)

type ServiceContext struct {
	Conf     *config.Config
	Otp      *otp.Key
	Db       *gorm.DB
	Limiter  *limiter.RateLimiter
	GhuPool  *tokens.Tokens
	BindPool *redis.Client
	UserPool *redis.Client
}

//func (s *ServiceContext) SaveOTPImage() {
//	image, err := s.Otp.Image(200, 200)
//	if err != nil {
//		panic(err)
//	}
//	f, err := os.OpenFile(s.Conf.OTP.ImageFile, os.O_WRONLY|os.O_CREATE, 0600)
//	if err != nil {
//		panic(err)
//	}
//	defer func(f *os.File) {
//		err := f.Close()
//		if err != nil {
//			panic(err)
//		}
//	}(f)
//	err = png.Encode(f, image)
//	if err != nil {
//		panic(err)
//	}
//}

func NewServiceContext(conf *config.Config) *ServiceContext {
	Otp, err := totp.Generate(totp.GenerateOpts{
		Period:      conf.OTP.Period,
		Digits:      otp.Digits(conf.OTP.Digits),
		Secret:      []byte(conf.OTP.Secret),
		Issuer:      conf.OTP.Issuer,
		AccountName: conf.OTP.AccountName,
	})
	if err != nil {
		panic(err)
	}
	db, err := gorm.Open(mysql.Open(conf.Dsn), &gorm.Config{
		Logger: logger.New(
			log.New(os.Stdout, "\r\n", log.LstdFlags), // io writer
			logger.Config{
				LogLevel: logger.Silent, // 设置为Silent静默模式
			},
		),
	})
	if err != nil {
		panic(err)
	}
	err = db.AutoMigrate(&typs.ActivateCode{}, &typs.DeviceBind{}, &typs.History{})
	if err != nil {
		panic(err)
	}
	Svc := &ServiceContext{
		Conf:    conf,
		Otp:     Otp,
		Db:      db,
		Limiter: limiter.NewRateLimiter(time.Duration(conf.Limiter.Interval)*time.Second, conf.Limiter.MaxIPPerToken),
		GhuPool: tokens.NewTokens(redis.NewClient(&redis.Options{
			Addr:     conf.Redis.Addr,     // Redis服务器地址
			Password: conf.Redis.Password, // 密码，如果有的话
			DB:       0,                   // 使用的数据库
		})),
		BindPool: redis.NewClient(&redis.Options{
			Addr:     conf.Redis.Addr,     // Redis服务器地址
			Password: conf.Redis.Password, // 密码，如果有的话
			DB:       1,                   // 使用的数据库
		}),
		UserPool: redis.NewClient(&redis.Options{
			Addr:     conf.Redis.Addr,     // Redis服务器地址
			Password: conf.Redis.Password, // 密码，如果有的话
			DB:       2,                   // 使用的数据库
		}),
	}
	return Svc
}
