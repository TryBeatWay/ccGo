package main

import (
	"copilot-enterprise/config"
	"copilot-enterprise/svc"
	"github.com/gin-gonic/gin"
	"os"
	"path/filepath"
)

var sContext *svc.ServiceContext

func init() {
	gin.SetMode(gin.ReleaseMode)
}

func main() {
	yaml, err := config.NewConfigFromYaml("etc/conf.yaml")
	if err != nil {
		panic(err)
	}
	sContext = svc.NewServiceContext(yaml)
	//sContext.SaveOTPImage()
	r := gin.Default()

	r.Use(func(c *gin.Context) {
		c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
		c.Writer.Header().Set("Access-Control-Allow-Credentials", "true")
		c.Writer.Header().Set("Access-Control-Allow-Headers", "Content-Type, Content-Length, Accept-Encoding, X-CSRF-Token, Authorization, accept, origin, Cache-Control, X-Requested-With")
		c.Writer.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS, GET, PUT, DELETE")
		if c.Request.Method == "OPTIONS" {
			c.AbortWithStatus(204)
			return
		}
		c.Next()
	})

	createAPIRoute(r)
	CreateAdminRoute(r)
	CreateClientRoute(r)

	distDir := "./dist"
	r.NoRoute(func(c *gin.Context) {
		file := filepath.Join(distDir, c.Request.URL.Path)
		if _, err := os.Stat(file); os.IsNotExist(err) {
			// 如果请求的文件不存在，返回Vue的index.html文件
			c.File(filepath.Join(distDir, "index.html"))
		} else {
			c.File(file)
		}
	})

	err = r.Run(sContext.Conf.ListenAddr)
	if err != nil {
		panic(err)
	}
}
