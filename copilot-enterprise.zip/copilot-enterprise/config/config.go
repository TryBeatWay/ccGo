package config

import (
	"gopkg.in/yaml.v3"
	"os"
)

type Config struct {
	Dsn             string `yaml:"Dsn"`
	ListenAddr      string `yaml:"ListenAddr"`
	VerificationUrl string `yaml:"VerificationUrl"`
	Redis           struct {
		Addr     string `yaml:"Addr"`
		Password string `yaml:"Password"`
	} `yaml:"Redis"`
	Limiter struct {
		MaxIPPerToken int `yaml:"MaxIPPerToken"`
		Interval      int `yaml:"Interval"`
	} `yaml:"Limiter"`
	ClientSet struct {
		RotationCycle   int64 `yaml:"RotationCycle"`
		RefreshInterval int64 `yaml:"RefreshInterval"`
	} `yaml:"ClientSet"`
	OTP struct {
		Period      uint   `yaml:"Period"`
		Digits      int    `yaml:"Digits"`
		Secret      string `yaml:"Secret"`
		Issuer      string `yaml:"Issuer"`
		AccountName string `yaml:"AccountName"`
	} `yaml:"OTP"`
	Deploy struct {
		ChatEnabled          bool   `yaml:"ChatEnable"`
		ChatJetbrainsEnabled bool   `yaml:"ChatJetbrainsEnabled"`
		PublicSuggestions    string `yaml:"PublicSuggestions"`
		Telemetry            string `yaml:"Telemetry"`
	} `yaml:"Deploy"`
}

func NewConfigDefault() *Config {
	return &Config{}
}

func NewConfigFromYaml(path string) (*Config, error) {
	c := NewConfigDefault()
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	err = yaml.Unmarshal(data, c)
	if err != nil {
		return nil, err
	}
	return c, nil
}
