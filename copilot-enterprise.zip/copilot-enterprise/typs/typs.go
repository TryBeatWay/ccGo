package typs

import (
	"time"

	"gorm.io/gorm"
)

type Model struct {
	ID        uint           `json:"-" gorm:"primarykey"`
	CreatedAt time.Time      `json:"createdAt"`
	UpdatedAt time.Time      `json:"-"`
	DeletedAt gorm.DeletedAt `json:"-" gorm:"index"`
}

type ActivateCode struct {
	Model
	Code             string        `json:"code" gorm:"unique_index"`
	GrantDeviceCount int           `json:"grantDeviceCount" gorm:"not null"`
	Name             string        `json:"name" gorm:"not null"`
	UsedDate         time.Time     `json:"usedDate" gorm:"not null"`
	ValidUntil       time.Duration `json:"validUntil" gorm:"not null"`
	DeviceBinds      []DeviceBind  `json:"deviceBinds" gorm:"foreignKey:ActivateCodeID;references:ID"`
}

type DeviceBind struct {
	Model
	Code                string        `json:"code" gorm:"not null"`
	ClientId            string        `json:"-" gorm:"not null"`
	DeviceCode          string        `json:"deviceCode" gorm:"not null"`
	ActivateCodeID      uint          `json:"-"`
	ActivateCode        *ActivateCode `json:"-"`
	EditorVersion       string        `json:"editorVersion"`
	EditorPluginVersion string        `json:"editorPluginVersion"`
	UserAgent           string        `json:"userAgent"`
}

type History struct {
	Model
	DeviceCode string `gorm:"not null"`
	IP         string `gorm:"not null"`
}

type GithubAuthResponse struct {
	AnnotationsEnabled                 bool   `json:"annotations_enabled"`
	ChatEnabled                        bool   `json:"chat_enabled"`
	ChatJetbrainsEnabled               bool   `json:"chat_jetbrains_enabled"`
	CodeQuoteEnabled                   bool   `json:"code_quote_enabled"`
	CopilotIDEAgentChatGPT4SmallPrompt bool   `json:"copilot_ide_agent_chat_gpt4_small_prompt"`
	CopilotIgnoreEnabled               bool   `json:"copilotignore_enabled"`
	ExpiresAt                          int64  `json:"expires_at"`
	IntellijEditorFetcher              bool   `json:"intellij_editor_fetcher"`
	Prompt8k                           bool   `json:"prompt_8k"`
	PublicSuggestions                  string `json:"public_suggestions"`
	RefreshIn                          int64  `json:"refresh_in"`
	SKU                                string `json:"sku"`
	SnippyLoadTestEnabled              bool   `json:"snippy_load_test_enabled"`
	Telemetry                          string `json:"telemetry"`
	Token                              string `json:"token"`
	TrackingID                         string `json:"tracking_id"`
	VSCPanelV2                         bool   `json:"vsc_panel_v2"`
}

type ErrorDetails struct {
	URL            string `json:"url"`
	Message        string `json:"message"`
	Title          string `json:"title"`
	NotificationID string `json:"notification_id"`
}

type ErrorResponse struct {
	Message      string       `json:"message"`
	ErrorDetails ErrorDetails `json:"error_details"`
}

type LoginRequest struct {
	ClientId   string `form:"client_id" json:"client_id"`
	DeviceCode string `form:"device_code" json:"device_code,omitempty"`
}

type AccessTokenResult struct {
	Error            string `json:"error"`
	ErrorDescription string `json:"error_description"`
	ErrorUri         string `json:"error_uri"`
}

func SetMessage(message string) *ErrorResponse {
	var errTokenAuthWithUnAvailable = ErrorResponse{
		Message: "服务受限,请稍后再试",
		ErrorDetails: ErrorDetails{
			Message:        message,
			URL:            "https://enterprise.mstp.online",
			Title:          "Copilot Enterprise",
			NotificationID: "feature_flag_blocked",
		},
	}
	errTokenAuthWithUnAvailable.Message = message
	return &errTokenAuthWithUnAvailable
}
