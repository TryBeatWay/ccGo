<template>
  <div class="container">
    <div class="input-group">
      <label>
        <input class="input-field" v-model="codeModel" type="text" placeholder="输入订阅码">
      </label>
      <button class="btn" @click="refreshToken">刷新负载账号</button>
    </div>
  </div>
</template>


<script>
import axios from 'axios';

export default {
  data() {
    return {
      error: null
    };
  },
  computed: {
    codeModel: {
      get() {
        return this.$store.state.code;
      },
      set(newValue) {
        this.$store.commit('setCode', newValue);
      }
    }
  },
  methods: {
    async refreshToken() {
      this.data = null;
      this.error = null;
      try {
        const response = await axios.get(window.url+'/client/refresh/token', {
          params: {
            code: this.codeModel,
          }
        });
        if (response.status === 200) {
          this.message = '刷新成功';
        } else {
          this.error = response.data;
        }
      } catch (error) {
        this.error = error.response.data;
      }
      this.$message({
        type: this.error ? 'error' : 'success',
        duration: 3000,
        showClose: true,
        center: true,
        message: this.error ? this.error : "刷新成功"
      });
    }
  }
};

</script>

<style scoped>
</style>