<template>
  <div class="home">
    <h1 class="caihong">Copilot Enterprise</h1>
    <p class="info">加入我们的QQ交流群: 744538958 </p>
    <p class="info"><a href="https://item.taobao.com/item.htm?ft=t&id=766921536997" target="_blank" rel="noopener noreferrer">官方淘宝店</a></p>
  </div>
</template>

<style scoped>
.home {
  display: flex;
  flex-direction: column;
  align-items: center;
  align-content: center;
  align-self: center;
  justify-content: center;
  height: 100vh;
  font-family: Arial, sans-serif;
}

.caihong {
  font-size: 3em;
  margin-bottom: 1em;
  background: linear-gradient(to right, violet, indigo, blue, green, yellow, orange, red);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  font-weight: bold;
}

.info {
  font-size: 1.2em;
}

.info a {
  color: #007BFF;
  text-decoration: none;
}

.info a:hover {
  text-decoration: underline;
}
</style>
<script setup>
</script>