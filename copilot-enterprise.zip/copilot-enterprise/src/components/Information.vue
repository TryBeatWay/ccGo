<template>
  <div class="container">
    <div class="input-group">
      <label>
        <input class="input-field" v-model="codeModel" type="text" placeholder="输入订阅码">
      </label>
      <label>
        <input class="input-field" v-model="name" type="text" placeholder="输入GitHub用户名(Chat中会使用此用户的头像)">
      </label>
      <button class="btn" @click="setAvatarName">设置</button>
    </div>
  </div>
</template>


<script>
import axios from 'axios';

export default {
  data() {
    return {
      name: '',
      error: null
    };
  },
  computed: {
    codeModel: {
      get() {
        return this.$store.state.code;
      },
      set(newValue) {
        this.$store.commit('setCode', newValue);
      }
    }
  },
  methods: {
    async setAvatarName() {
      this.data = null;
      this.error = null;
      try {
        const response = await axios.get(window.url+'/client/setAvatarName', {
          params: {
            name: this.name,
            code: this.codeModel,
          }
        });
        if (response.status === 200) {
          this.message = '设置成功';
        } else {
          this.error = response.data;
        }
      } catch (error) {
        this.error = error.response.data;
      }
      this.$message({
        type: this.error ? 'error' : 'success',
        duration: 3000,
        showClose: true,
        center: true,
        message: this.error ? this.error : "设置成功"
      });
    }
  }
};

</script>

<style scoped>
</style>