<template>
  <div class="container">
    <div class="input-group">
      <input class="input-field" v-model="codeModel" placeholder="请输入订阅码">
      <input class="input-field" v-model="deviceCode" placeholder="请输入EPU(36位UUID/epu_)">
      <button class="btn" @click="unbind">立即解绑</button>
    </div>

    <div v-if="response" class="response">
      <pre>{{ response }}</pre>
    </div>

    <div v-if="error" class="error">{{ error }}</div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      deviceCode: '',
      response: null,
      error: null,
    }
  },
  computed: {
    codeModel: {
      get() {
        return this.$store.state.code;
      },
      set(newValue) {
        this.$store.commit('setCode', newValue);
      }
    }
  },
  methods: {
    async unbind() {
      this.data = null;
      this.error = null;
      try {
        const response = await axios.get(window.url+'/client/unbind', {
          params: {
            code: this.codeModel,
            device_code: this.deviceCode
          }
        });
        if (response.status === 200) {
          this.response = response.data;
          this.error = null;
        } else {
          this.error = response.data;
        }
      } catch (error) {
        this.error = error.response.data;
      }
    }
  }
}
</script>

<style scoped>

</style>