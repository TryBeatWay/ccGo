<template>
  <div class="container">
    <div class="input-group">
      <input class="input-field" v-model="codeModel" placeholder="请输入订阅码">
      <button class="btn" @click="bind">获取EPUToken</button>
    </div>

    <div v-if="response" class="caihong">
      <pre>{{ response }}</pre>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      response: null,
      error: null,
    }
  },
  computed: {
    codeModel: {
      get() {
        return this.$store.state.code;
      },
      set(newValue) {
        this.$store.commit('setCode', newValue);
      }
    }
  },
  methods: {
    async bind() {
      this.data = null;
      this.error = null;
      try {
        const response = await axios.get(window.url+'/client/epuToken', {
          params: {
            code: this.codeModel,
          }
        });
        if (response.status === 200) {
          this.response = response.data;
          this.error = null;
        } else {
          this.error = response.data;
        }
      } catch (error) {
        this.error = error.response.data;
      }
      this.$message({
        type: this.error ? 'error' : 'success',
        duration: 3000,
        showClose: true,
        center: true,
        message: this.error ? this.error : this.response
      });
    }
  }
}
</script>

<style scoped>
.caihong {
  background: linear-gradient(to right, violet, indigo, blue, green, yellow, orange, red);
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  font-weight: bold;
}
</style>