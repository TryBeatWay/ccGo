<template>
  <div class="container">
    <div class="input-group">
      <input class="input-field" v-model="codeModel" placeholder="请输入订阅码">
      <input class="input-field" v-model="userCode" placeholder="请输入设备码(1111-2222)" type="text" :maxlength="9">
      <button class="btn" @click="bind">立即绑定</button>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import { ElButton, ElDialog } from 'element-plus';
import 'element-ui/lib/theme-chalk/index.css';

export default {
  components: {
    ElButton,
    ElDialog
  },
  data() {
    return {
      userCode: '',
      response: null,
      error: null,
    }
  },
  computed: {
    codeModel: {
      get() {
        return this.$store.state.code;
      },
      set(newValue) {
        this.$store.commit('setCode', newValue);
      }
    }
  },
  methods: {
    async bind() {
      this.data = null;
      this.error = null;
      try {
        const response = await axios.get(window.url + '/client/bind', {
          params: {
            code: this.codeModel,
            user_code: this.userCode
          }
        });
        if (response.status === 200) {
          this.response = response.data;
          this.error = null;
        } else {
          this.error = response.data;
        }
      } catch (error) {
        this.error = error.response.data;
      }
      this.$message({
        type: this.error ? 'error' : 'success',
        duration: 3000,
        showClose: true,
        center: true,
        message: this.error ? this.error : this.response
      });
    }
  }
}
</script>

<style scoped>

</style>