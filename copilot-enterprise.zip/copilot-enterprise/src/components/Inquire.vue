<template>
  <div class="container">
    <div class="content">
      <div>
        <div class="input-group">
          <input class="input-field" v-model="codeModel" placeholder="输入订阅码">
          <button class="btn" @click="inquire">查询</button>
        </div>
        <div v-if="data1 && data2" class="response">
          <el-row justify="space-between">
            <el-col :span="12">
              <p><strong>首次使用于: </strong> {{ formatDate(data1.usedDate) }}</p>
              <p><strong>订阅时长: </strong> {{ validUntilDays }} 天</p>
              <p><strong>GitHub用户名: </strong> {{ data1.name }}</p>
            </el-col>
            <el-col :span="8">
              <p><strong>剩余可用订阅设备数: </strong> {{ data1.grantDeviceCount - data1.deviceBinds.length }}</p>
              <p><strong>24小时内请求数: </strong>{{ data2.total_histories }}</p>
              <p><strong>24小时内IP数: </strong>{{ data2.unique_ips }}</p>
            </el-col>
          </el-row>
        </div>
        <div>
          <ul v-if="data1 && data1.deviceBinds && data1.deviceBinds.length !== 0" class="response scrollable">
            <li v-for="bind in data1.deviceBinds" :key="bind">
              <el-card class="device-binds">
                <el-row justify="start">
                  <el-col :span="18">
                    <!--                    <p><strong>设备码: </strong> {{ bind.deviceCode }}</p>-->
                    <p><strong>绑定时间: </strong> {{ formatDate(bind.createdAt) }}</p>
                    <p><strong>IDE类型: </strong> {{ bind.editorVersion }}</p>
                  </el-col>
                  <el-col :span="6">
                    <button class="btn btn-danger" style="display: grid;align-items: center;justify-content: center"
                            @click="unbind(bind.deviceCode)">解绑
                    </button>
                  </el-col>
                </el-row>
              </el-card>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.response {
  //border: 1px solid #66b1ff; /* adjust color as needed */
  border-radius: 5px; /* adjust as needed */
  background-color: #f0f8ff; /* adjust color as needed */
  padding: 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

ul {
  list-style-type: none;
}

.response p {
  margin-bottom: 10px;
  font-size: 20px;
  line-height: 1.5;
}

.scrollable {
  overflow: auto;
  max-height: 400px; /* adjust this value as needed */
}

.device-binds {
  margin-bottom: 10px;
}

/* Chrome */
.scrollable::-webkit-scrollbar {
  width: 5px;
}

.scrollable::-webkit-scrollbar-track {
  background: transparent;
}

.scrollable::-webkit-scrollbar-thumb {
  background: linear-gradient(to bottom, red, orange, yellow, green, blue);
  border-radius: 5px;
}

/* Firefox */
.scrollable {
  scrollbar-width: thin;
  scrollbar-color: transparent transparent;
}

.scrollable::-webkit-scrollbar-thumb {
  background: linear-gradient(to bottom, red, orange, yellow, green, blue);
  border-radius: 5px;
}
</style>

<script>
import axios from 'axios'

export default {
  data() {
    return {
      data1: null,
      data2: null,
      error: null,
    }
  },
  computed: {
    validUntilDays() {
      return this.data1 && this.data1.validUntil
          ? Math.round(this.data1.validUntil / (24 * 60 * 60 * 1000000000))
          : '';
    },
    codeModel: {
      get() {
        return this.$store.state.code;
      },
      set(newValue) {
        this.$store.commit('setCode', newValue);
      }
    }
  },
  methods: {
    formatDate(dateString) {
      const date = new Date(dateString);
      const options = {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false
      };
      return new Intl.DateTimeFormat('cn-US', options).format(date);
    },
    async inquire() {
      this.data1 = null;
      this.data2 = null;
      this.error = null;
      try {
        const response1 = await axios.get(window.url + '/client/inquire', {
          params: {
            code: this.codeModel
          }
        });
        this.data1 = response1.data;
        if (response1.status !== 200) {
          this.error = response1.data;
        }
        const response2 = await axios.get(window.url + '/client/history', {
          params: {
            code: this.codeModel
          }
        });
        this.data2 = response2.data;
      } catch (error) {
        if (error.response) {
          this.error = error.response;
        }
        // this.error = error.response.data;
      }
      if (this.error != null) {
        this.$message({
          type: 'error',
          duration: 3000,
          showClose: true,
          center: true,
          message: this.error
        });
      }
    },
    async unbind(deviceCode) {
      this.error = null;
      try {
        const response = await axios.get(window.url + '/client/unbind', {
          params: {
            code: this.codeModel,
            device_code: deviceCode
          }
        });
        if (response.status === 200) {
          this.response = response.data;
          this.data1.deviceBinds = this.data1.deviceBinds.filter(bind => bind.deviceCode !== deviceCode);
          this.error = null;
        } else {
          this.error = response.data;
        }
      } catch (error) {
        this.error = error.response;
      }
      this.$message({
        type: this.error ? 'error' : 'success',
        duration: 3000,
        showClose: true,
        center: true,
        message: this.error ? this.error.data : this.response
      });
    }
  }
}
</script>

