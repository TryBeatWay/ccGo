<template>
  <div id="app">
    <nav class="navigation">
      <router-link class="nav-link" to="/">主页</router-link>
      <router-link class="nav-link" to="/bind">绑定</router-link>
      <router-link class="nav-link" to="/getToken">获取EPUToken</router-link>
      <!--      <router-link class="nav-link" to="/unbind">解绑</router-link>-->
      <router-link class="nav-link" to="/inquire">查询订阅|解绑</router-link>
      <router-link class="nav-link" to="/information">个人信息</router-link>
      <router-link class="nav-link" to="/refreshToken">刷新负载账号</router-link>
    </nav>
    <router-view/>
  </div>
</template>

<style scoped>
#app {
  display: flex;
  flex-direction: column;
}

.navigation {
  width: 100%;
  background-color: #f0f8ff;
  position: relative;
  display: flex;
  justify-content: space-around;
  padding: 10px 10px;
}

.navigation::after {
  content: "";
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 3px;
  background: linear-gradient(to right, red, orange, yellow, green, blue);
}

.nav-link {
  text-decoration: none;
  padding: 10px 20px;
  text-align: center;
  transition: color 0.3s ease, background-color 0.3s ease;
  border-radius: 15px;
  background-color: #007bff;
  color: #fff;
}

.nav-link:hover {
  color: #fff;
  background-color: #0056b3;
}

/* Add media query for mobile devices */
@media (max-width: 768px) {
  .navigation {
    flex-direction: row;
    align-items: center;
  }

  .nav-link {
    padding: 10px 10px;
    font-size: 0.8em;
  }
}
</style>

<script setup>
</script>
