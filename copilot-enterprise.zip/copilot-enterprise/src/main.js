// main.js
import {createApp} from 'vue'
import {createRouter, createWebHistory} from 'vue-router'
import Home from './components/Home.vue'
import Inquire from './components/Inquire.vue'
import Bind from './components/Bind.vue'
import Information from './components/Information.vue'
import './styles.css';
import store from "./store.js";
import 'element-plus/dist/index.css'
import ElementPlus from 'element-plus'
import App from './App.vue'
import GetToken from "@/components/GetToken.vue";
import UnBind from "@/components/UnBind.vue";
import RefreshToken from "@/components/RefreshToken.vue";
window.url = 'https://'+window.location.hostname;
// window.url = 'http://'+'127.0.0.1:60000';

const router = createRouter({
    history: createWebHistory(),
    routes: [
        {path: '/', component: Home},
        {path: '/bind', component: Bind},
        {path: '/unbind', component: UnBind},
        {path: '/getToken', component: GetToken},
        {path: '/information', component: Information},
        {path: '/inquire', component: Inquire},
        {path: '/refreshToken', component: RefreshToken},
    ],
})

createApp(App).use(router).use(ElementPlus).use(store).mount('#app')
