import { createStore } from 'vuex'

export default createStore({
    state: {
        code: ''
    },
    mutations: {
        setCode(state, newValue) {
            state.code = newValue
        }
    }
})