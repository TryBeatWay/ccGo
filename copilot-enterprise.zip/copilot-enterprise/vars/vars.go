package vars

import "copilot-enterprise/typs"

var ErrEpuTokenAuthWithFormattingError = typs.SetMessage("设备码填写格式错误")
var ErrTokenAuthWithUnAvailable = typs.SetMessage("订阅码不存在")
var ErrTokenAuthWithExpired = typs.SetMessage("订阅已过期 请联系客服续费")
var ErrTokenWithTooManyRequests = typs.SetMessage("您的设备码短时间内被多个IP请求 请稍后再试")
var ErrTokenWithServiceAbnormal = typs.SetMessage("我们的服务进入高峰期 请稍后再试")
var ErrTokenAuthWithNeedReActivate = typs.SetMessage("当前设备已被解绑 请退出账号 重新授权")
var ErrTokenWithNeedRecharge = typs.SetMessage("您当前的订阅码已被停用 请联系客服")

var AccessTokenResult = typs.AccessTokenResult{
	Error:            "authorization_pending",
	ErrorDescription: "The authorization request is still pending.",
	ErrorUri:         "",
}
