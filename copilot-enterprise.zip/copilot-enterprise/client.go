package main

import (
	"context"
	"copilot-enterprise/typs"
	"crypto/rand"
	"github.com/gin-gonic/gin"
	"gorm.io/gorm"
	"time"
)

func GenerateToken(prefix string, length int) string {
	const letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
	bytes := make([]byte, length)
	if _, err := rand.Read(bytes); err != nil {
		panic(err)
	}

	for i, b := range bytes {
		bytes[i] = letters[b%byte(len(letters))]
	}

	return prefix + string(bytes)
}

type Result struct {
	TotalHistories int `json:"total_histories"`
	UniqueIPs      int `json:"unique_ips"`
}

func getHistoryStats(db *gorm.DB, activateCode string, hours int) (Result, error) {
	var result Result
	err := db.Table("device_binds").
		Select("COUNT(*) AS total_histories, COUNT(DISTINCT histories.ip) AS unique_ips").
		Joins("JOIN activate_codes ON device_binds.activate_code_id = activate_codes.id").
		Joins("JOIN histories ON device_binds.device_code = histories.device_code").
		Where("activate_codes.code = ? AND histories.created_at >= NOW() - INTERVAL ? HOUR", activateCode, hours).
		Scan(&result).Error

	return result, err
}

func CreateClientRoute(r *gin.Engine) {
	g := r.Group("/client")
	g.GET("/setAvatarName", func(c *gin.Context) {
		name := c.Query("name")
		code := c.Query("code")
		var activateCode = typs.ActivateCode{
			Name: name,
			Code: code,
		}
		tx := sContext.Db.Where("code = ?", code).Updates(&activateCode)
		if tx.Error != nil {
			c.String(403, tx.Error.Error())
			return
		}
		if tx.RowsAffected == 0 {
			c.String(403, "订阅码不存在")
			return
		}
	})
	g.GET("/inquire", func(c *gin.Context) {
		code := c.Query("code")
		var activateCode typs.ActivateCode
		err := sContext.Db.Where("code = ?", code).Preload("DeviceBinds").First(&activateCode).Error
		if err != nil {
			c.String(403, err.Error())
			return
		}
		c.JSONP(200, activateCode)
	})
	g.GET("/history", func(c *gin.Context) {
		stats, err := getHistoryStats(sContext.Db, c.Query("code"), 24)
		if err != nil {
			c.String(403, err.Error())
			return
		}
		c.JSONP(200, stats)
	})
	g.GET("/unbind", func(c *gin.Context) {
		code := c.Query("code")
		deviceCode := c.Query("device_code")
		var deviceBind typs.DeviceBind
		if err := sContext.Db.Where("code = ? AND device_code = ?", code, deviceCode).First(&deviceBind).Error; err != nil {
			c.String(403, "绑定设备已被解绑或不存在")
			return
		} else {
			sContext.Db.Delete(&deviceBind)
		}
		c.String(200, "解绑成功")
	})
	g.GET("/bind", func(c *gin.Context) {
		userCode := c.Query("user_code")
		code := c.Query("code")
		result, err := sContext.BindPool.Get(context.Background(), userCode).Result()
		if err != nil {
			c.String(403, "未找到待授权设备")
			return
		}
		var activateCode typs.ActivateCode
		err = sContext.Db.Where("code = ?", code).Preload("DeviceBinds").First(&activateCode).Error
		if err != nil {
			c.String(403, "订阅码不存在")
			return
		}
		if activateCode.UsedDate.IsZero() {
			activateCode.UsedDate = time.Now()
			err := sContext.Db.Updates(&activateCode).Error
			if err != nil {
				c.String(403, "服务内部错误 绑定失败")
				return
			}
		}
		if len(activateCode.DeviceBinds) >= activateCode.GrantDeviceCount {
			c.String(403, "订阅码已达到到最大设备数 请先进行解绑")
			return
		}
		err = sContext.Db.Model(&activateCode).Association("DeviceBinds").Append(&typs.DeviceBind{
			Code:       code,
			DeviceCode: result,
		})
		if err != nil {
			c.String(403, "服务内部错误 绑定失败")
			return
		}
		if err = sContext.BindPool.Del(context.Background(), userCode).Err(); err != nil {
			c.String(403, "服务内部错误 绑定失败")
			return
		}
		c.String(200, "绑定成功")
	})
	g.GET("/epuToken", func(c *gin.Context) {
		code := c.Query("code")
		var activateCode typs.ActivateCode
		err := sContext.Db.Where("code = ?", code).Preload("DeviceBinds").First(&activateCode).Error
		if err != nil {
			c.String(403, "订阅码不存在")
			return
		}
		if activateCode.UsedDate.IsZero() {
			activateCode.UsedDate = time.Now()
			err := sContext.Db.Updates(&activateCode).Error
			if err != nil {
				c.String(403, "服务内部错误 绑定失败")
				return
			}
		}
		if len(activateCode.DeviceBinds) >= activateCode.GrantDeviceCount {
			c.String(403, "订阅码已达到到最大设备数 请先进行解绑")
			return
		}
		epuToken := GenerateToken("epu_", 36)
		err = sContext.Db.Model(&activateCode).Association("DeviceBinds").Append(&typs.DeviceBind{
			Code:       code,
			DeviceCode: epuToken,
		})
		if err != nil {
			c.String(403, "服务内部错误 绑定失败")
			return
		}
		c.String(200, "EPUToken: "+epuToken)
	})
	g.GET("/refresh/token", func(c *gin.Context) {
		code := c.Query("code")
		rowEffect, err := sContext.UserPool.Del(context.Background(), code).Result()
		if err != nil {
			c.String(403, "服务内部错误 刷新失败")
			return
		}
		if rowEffect == 0 {
			c.String(403, "订阅码无效|当前无在线设备 无需刷新")
			return
		}
		c.String(200, "刷新成功")
	})
}
