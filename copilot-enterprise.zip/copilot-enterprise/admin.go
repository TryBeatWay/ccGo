package main

import (
	"copilot-enterprise/typs"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/pquerna/otp"
	"github.com/pquerna/otp/totp"
	"strings"
	"time"
)

// OTPMiddleware 中间件
func OTPMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		otpCode := c.Query("otp")

		// 验证OTP
		if ok, err := (totp.ValidateCustom(otpCode, sContext.Otp.Secret(), time.Now(),
			totp.ValidateOpts{Digits: otp.Digits(sContext.Conf.OTP.Digits), Period: sContext.Conf.OTP.Period})); err != nil || !ok {
			c.String(400, "OTP验证失败")
			c.Abort()
			return
		}
	}

}

func handleError(c *gin.Context, err error) {
	if err != nil {
		c.JSON(400, gin.H{"error": err})
		c.Abort()
	}
}

func createOrUpdateActivateCode(code string, days int, deviceCount int) typs.ActivateCode {
	return typs.ActivateCode{
		Code:             code,
		ValidUntil:       time.Duration(days) * 24 * time.Hour,
		UsedDate:         time.Time{},
		GrantDeviceCount: deviceCount,
	}
}

func CreateAdminRoute(r *gin.Engine) {
	admin := r.Group("/admin")
	admin.Use(OTPMiddleware())
	{
		admin.GET("/code/create", func(c *gin.Context) {
			var req struct {
				Count       int `form:"count"`
				Days        int `form:"days"`
				DeviceCount int `form:"deviceCount"`
			}
			handleError(c, c.ShouldBind(&req))

			var codes = make([]string, req.Count)
			for i := 0; i < req.Count; i++ {
				codes[i] = uuid.New().String()
			}

			generatedCodes := make([]typs.ActivateCode, req.Count)
			for i, code := range codes {
				generatedCodes[i] = createOrUpdateActivateCode(code, req.Days, req.DeviceCount)
			}

			handleError(c, sContext.Db.Create(&generatedCodes).Error)

			c.String(200, strings.Join(codes, "\n"))
		})

		admin.GET("/code/addTime", func(c *gin.Context) {
			var req struct {
				Code        string `form:"code"`
				Days        int    `form:"days"`
				DeviceCount int    `form:"deviceCount"`
			}
			handleError(c, c.ShouldBind(&req))

			var activateCode typs.ActivateCode
			handleError(c, sContext.Db.Where("code=?", req.Code).First(&activateCode).Error)

			activateCode = createOrUpdateActivateCode(req.Code, req.Days, req.DeviceCount)
			err := sContext.Db.Where("code = ?", req.Code).Updates(&activateCode).Error
			if err != nil {
				c.String(400, err.Error())
				return
			}

			c.JSON(200, gin.H{"code": req.Code, "newDuration": fmt.Sprintf("%.2f", activateCode.ValidUntil.Hours()/24)})
		})

		admin.GET("/code/delete", func(c *gin.Context) {
			var req struct {
				Code string `form:"code"`
			}
			handleError(c, c.ShouldBind(&req))

			var activateCode typs.ActivateCode
			handleError(c, sContext.Db.Where("code=?", req.Code).Preload("device_binds").First(&activateCode).Error)
			handleError(c, sContext.Db.Delete(&activateCode.DeviceBinds).Error)
			handleError(c, sContext.Db.Delete(&activateCode).Error)

			c.JSON(200, gin.H{"deletedCode": req.Code})
		})
	}
}
