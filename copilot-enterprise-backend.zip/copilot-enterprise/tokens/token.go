package tokens

import (
	"context"
	"github.com/go-redis/redis/v8"
)

type Tokens struct {
	redis *redis.Client
}

func NewTokens(redis *redis.Client) *Tokens {
	return &Tokens{redis: redis}
}

func (t *Tokens) GetValue(key string) (string, error) {
	value, err := t.redis.Get(context.Background(), key).Result()
	if err != nil {
		return "", err
	}
	return value, nil
}

func (t *Tokens) GetKeyValueRandom() (string, string, error) {
	key, err := t.redis.RandomKey(context.Background()).Result()
	if err != nil {
		return "", "", err
	}
	value, err := t.redis.Get(context.Background(), key).Result()
	if err != nil {
		return "", "", err
	}
	return key, value, nil
}
