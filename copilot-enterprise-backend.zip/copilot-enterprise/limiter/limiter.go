package limiter

import (
	"sync"
	"time"
)

type RateLimiter struct {
	tokenIPMap    map[string]map[string]struct{}
	mutex         sync.Mutex
	maxIPPerToken int
	interval      time.Duration
}

func NewRateLimiter(interval time.Duration, maxIPToken int) *RateLimiter {
	return &RateLimiter{
		tokenIPMap:    make(map[string]map[string]struct{}),
		interval:      interval,
		maxIPPerToken: maxIPToken,
	}
}

func (rl *RateLimiter) Allow(token, ip string) bool {
	rl.mutex.Lock()
	defer rl.mutex.Unlock()
	go rl.resetTokens(token)
	if v, ok := rl.tokenIPMap[token]; ok {
		if len(v) > rl.maxIPPerToken {
			return false
		}
		v[ip] = struct{}{}
		return true
	}
	rl.tokenIPMap[token] = make(map[string]struct{}, rl.maxIPPerToken)
	return true
}

func (rl *RateLimiter) resetTokens(token string) {
	time.Sleep(rl.interval)
	rl.mutex.Lock()
	defer rl.mutex.Unlock()
	delete(rl.tokenIPMap, token)
}
